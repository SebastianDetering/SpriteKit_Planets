//
//  ViewController.swift
//  Animate2DTests
//
//  Created by sebi d on 4.3.21.
//

import Cocoa
import SpriteKit
import GameplayKit

class ViewController: NSViewController {

    @IBOutlet var skView: SKView!
    var currentscene : GameScene? = nil
    override func viewDidLoad() {
        super.viewDidLoad()

        if let view = self.skView {
            // Load the SKScene from 'GameScene.sks'
            if let scene = GameScene(fileNamed: "GameScene") {
                // Set the scale mode to scale to fit the window
                scene.scaleMode = .aspectFill
                
                // Present the scene
                view.presentScene(scene)
                currentscene = scene
            }
            
            view.ignoresSiblingOrder = true
    
            
            view.showsFPS = true
            view.showsNodeCount = true
        }
    }
    @IBOutlet weak var eccentricityValueField: NSTextField!
    @IBAction func sliderDidChange(_ sender: NSSlider) {
        let newEcc = sender.floatValue
        eccentricityValueField.floatValue = newEcc
        currentscene!.newEccentricity(newEccentricity: newEcc)
    }
}

