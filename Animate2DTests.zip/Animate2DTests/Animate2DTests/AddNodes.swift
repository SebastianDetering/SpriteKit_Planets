//
//  AddNodes.swift
//  Animate2DTests
//
//  Created by sebi d on 4.3.21.
//

import SpriteKit



func getAlpha( ecc: CGFloat, ellipse: SKNode) -> CGFloat {
    let width = ellipse.frame.width / 2
    return CGFloat((1 - pow(ecc, 2) )) * width
}
