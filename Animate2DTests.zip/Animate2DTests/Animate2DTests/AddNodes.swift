//
//  AddNodes.swift
//  Animate2DTests
//
//  Created by sebi d on 4.3.21.
//

import SpriteKit

let body1 = SKShapeNode(circleOfRadius: 10)
let body2 = SKShapeNode(circleOfRadius: 25)
let ecc : CGFloat = 0.3
var alpha : CGFloat = 0

extension GameScene {
func addNodes( parent : SKNode ) {
    body1.alpha = 1
    body1.position = CGPoint(x: 10, y: 20)
    body1.lineWidth = 0
    body1.fillColor = NSColor(red: 0.1, green: 0.1, blue: 0.9, alpha: 1)
    body2.alpha = 1
    body2.position = CGPoint(x: 400, y: 500)
    body2.lineWidth = 0
    body2.fillColor = NSColor(red: 0.9, green: 0.9, blue: 0.1, alpha: 1)
    // position them initially here.
    let path = makeOrbitPath(scene : parent, eccentricity : ecc )

    body2.position = path.position
    body2.position.x -= CGFloat(ecc) * path.frame.width / 2

    alpha = (ecc * path.frame.width * 1.16) * ( 1 + ecc )
    print(alpha)
    
    parent.addChild( path )
    parent.addChild( body2 )
    parent.addChild( body1 )
}

}
