//
//  Planet.swift
//  Animate2DTests
//
//  Created by sebi d on 4.3.21.
//

import SpriteKit

class Body : SKShapeNode {
    
}


public var viewangle : Float = 0
public var scale_factor : CGFloat = 0

extension GameScene {
func makeOrbitPath( scene : SKNode, eccentricity : CGFloat ) -> SKShapeNode {
    // adds a path, positions bodies.
    var width = scene.frame.width
    var height = scene.frame.height
    let horizontal_buffer : CGFloat = 0.2
    let vertical_buffer   : CGFloat = 0.2 // percents that determine region the placing will avoid.
    width *=  (1 - horizontal_buffer )
    height *= (1 - vertical_buffer   )
    
    let abratio : CGFloat = CGFloat( sqrtf(1 - pow(Float(eccentricity) , 2) ) )
    let a : CGFloat = 1 // placeholder value, doesnt matter as long as it isn't zero
    let b : CGFloat = abratio * a
    // we want enough scope so that
    if viewangle == 0 {
        scale_factor = height / b
        if scale_factor * a > width {
            scale_factor = width / a
        }
    } else {
        scale_factor = CGFloat(height) / (  CGFloat(a) * CGFloat( sin( viewangle )) +  CGFloat(b) * CGFloat( cos( viewangle )) )
    }
    let out_path =  SKShapeNode(ellipseOf: CGSize( width : a * scale_factor, height : b * scale_factor) )
    out_path.zRotation = CGFloat( viewangle )
    out_path.position  = CGPoint( x: scene.frame.width / 2 , y: scene.frame.height / 2 )
    out_path.name = "path"
    return out_path
}

func radiusCalc( ep : Float, alpha : Float, angle : Float) -> Float {
    return alpha / ( 1 - ep * cos( angle ) )
}

func movePlanet( theta : Float, planet : SKNode, alpha : Float, ep : Float) {
    let path = self.childNode(withName: "path")
    let offset = CGFloat( ep ) * path!.frame.width / 2
    let newrad = radiusCalc( ep: ep, alpha: alpha, angle : theta )
    let newx   = newrad * Float( cos( Double( theta )))
    let newy   = newrad * Float( sin( Double( theta )))
    
    planet.position = path!.position
    planet.position.x = -offset + CGFloat(newx) + path!.position.x
    planet.position.y = CGFloat(newy) + path!.position.y
}
// alpha = (CGFloat(ecc) * path.frame.width / 2)( 1 + ecc )
// r_0  =  a / 2 - (CGFloat(ecc) * path.frame.width / 2)          ( in our space has offset - (CGFloat(ecc) * path.frame.width / 2)  from ellipse origin )

func calcExtremes( ep : Float, alpha : Float ) -> [Float] {
    if ep == 1 {
        // (hyperbolic)
        print( "hyperbolic approach (ep = 1)")
        return [ alpha / 2 ]
    }
    return [ alpha / ( 1 - ep), alpha / (1 + ep )]
}


}
