//
//  GameScene.swift
//  Animate2DTests
//
//  Created by sebi d on 4.3.21.
//

import SpriteKit
import GameplayKit
import SwiftUI


let body1 = Body(circleOfRadius: 10)
let body2 = SKShapeNode(circleOfRadius: 20)
var alpha : CGFloat = 1

class GameScene: SKScene {
    var path : SKShapeNode?
    var ecc : CGFloat = 0.5

    private var label : SKLabelNode?
    private var spinnyNode : SKShapeNode?
    
    var theta : Float = 0
    let time_scale : Double = 10
    var start_time : Double = Double( Float(CVGetCurrentHostTime()) / pow(10, 9) )
    var previousTime : Float = 0.0
    override func didMove(to view: SKView) {
        print("start_time is \(start_time)")
        addNodes(parent: self)
    }
    
    func newEccentricity(newEccentricity : Float ) {
        ecc = CGFloat( newEccentricity)
        addNodes(parent: self)
    }
    
    override func update(_ currentTime: TimeInterval) {
        // Called before each frame is rendered
        
        let time : Float = Float(time_scale * (currentTime - start_time))
        let timeChange : Float = time - Float(previousTime)
        previousTime = time
        movePlanet(timeChange: timeChange, planet: body1, alpha: Float(alpha), ep: Float(ecc) )
        
    }
}

extension GameScene {
    
    func clearOrbitPaths(path: SKNode) {
        self.path!.removeFromParent()
    }
func addNodes( parent : SKNode ) {
    body1.alpha = 1
    body1.position = CGPoint(x: 10, y: 20)
    body1.lineWidth = 0
    body1.fillColor = NSColor(red: 0.1, green: 0.1, blue: 0.9, alpha: 1)
    body2.alpha = 1
    // position them initially here.
    if path != nil {
        clearOrbitPaths(path: path!)
    }
    self.path = makeOrbitPath(scene : parent, eccentricity : ecc )
    interpolateRate(ep: Float(ecc), alpha: Float(alpha))
    
    body2.position = CGPoint(x: 400, y: 500)
    body2.lineWidth = 0
    body2.fillColor = NSColor(red: 0.9, green: 0.9, blue: 0.1, alpha: 1)
    body2.position = path!.position
    body2.position.x += CGFloat(ecc) * path!.frame.width / 2

    alpha = getAlpha(ecc: ecc, ellipse : path!)
    print(alpha)
    
    parent.addChild( path! )
    parent.addChild( body2 )
    parent.addChild( body1 )
}

}









//// all the below is Mac OS 11 stuff ( not needed )
//struct ContentView : View {
//    var scene : SKScene {
//        let scene = GameScene()
//        scene.size = CGSize(width : 300, height : 400)
//        scene.scaleMode = .fill
//        return scene
//    }
//
//
//    var body : some View {
//        SpriteView(scene : scene)
//            .frame(width: 300, height: 400)
//            .ignoresSafeArea()
//    }
//}
//// end of Mac OSX 11 stuff
