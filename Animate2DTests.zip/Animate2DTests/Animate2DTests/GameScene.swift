//
//  GameScene.swift
//  Animate2DTests
//
//  Created by sebi d on 4.3.21.
//

import SpriteKit
import GameplayKit
import SwiftUI

class GameScene: SKScene {
    
    private var label : SKLabelNode?
    private var spinnyNode : SKShapeNode?
    
    var theta : Float = 0
    let time_scale : Double = 0.2
    var start_time : Double = Double( Float(CVGetCurrentHostTime()) / pow(10, 9) )

    override func didMove(to view: SKView) {
        print("start_time is \(start_time)")
        addNodes(parent: self)
    }

    
    override func update(_ currentTime: TimeInterval) {
        // Called before each frame is rendered
        
        let theta_change : Float = Float(time_scale * (currentTime - start_time))
        print(theta_change)
        movePlanet(theta: theta_change, planet: body1, alpha: Float(alpha), ep: Float(ecc) )
        
    }
}












//// all the below is Mac OS 11 stuff ( not needed )
//struct ContentView : View {
//    var scene : SKScene {
//        let scene = GameScene()
//        scene.size = CGSize(width : 300, height : 400)
//        scene.scaleMode = .fill
//        return scene
//    }
//
//
//    var body : some View {
//        SpriteView(scene : scene)
//            .frame(width: 300, height: 400)
//            .ignoresSafeArea()
//    }
//}
//// end of Mac OSX 11 stuff
